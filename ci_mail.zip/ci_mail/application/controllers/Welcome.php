<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {


	public function index()
	{
		
	}
	
	function send_email() {

    $ci = &get_instance();
$ci->load->library('email');
$config['protocol'] = "smtp";
$config['smtp_host'] = "ssl://smtp.gmail.com";
$config['smtp_port'] = "465";
$config['smtp_timeout'] = '7';
$config['smtp_user'] = "anoop.clavis@gmail.com"; 
$config['smtp_pass'] = "hello.1234";
$config['charset'] = "utf-8";
$config['mailtype'] = "html"; // or html
$config['newline'] = "\r\n";

$ci->email->initialize($config);

$ci->email->from('anoop.clavis@gmail.com', 'Anoop Rai');
$list = array('anoop.clavis@gmail.com');
$ci->email->to($list);
$ci->email->reply_to('anoop.clavis@gmail.com', 'Explendid Videos');
$ci->email->subject('This is an email test');
$data = array(
             'userName'=> 'Anoop Rai'
             );
$body = $ci->load->view('email_view',$data,TRUE);
$ci->email->message($body); 


if($ci->email->send())
{
	echo "Successfull";
}
else 
{
	echo $this->email->print_debugger();
}
	
}



}
