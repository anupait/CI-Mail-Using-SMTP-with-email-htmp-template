<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>This is Anoop Rai Email Script Using SMTP</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body>
<div>
   <div style="font-size: 26px;font-weight: 700;letter-spacing: -0.02em;line-height: 32px;color: #41637e;font-family: sans-serif;text-align: center" align="center" id="emb-email-header"><img style="border: 0;-ms-interpolation-mode: bicubic;display: block;Margin-left: auto;Margin-right: auto;max-width: 152px" src="https://upload.wikimedia.org/wikipedia/en/c/c3/Task_Force_Logo_No_Name.jpg" alt="" width="152" height="108"><p>Anoop Rai</p></div>
<p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px">Hey <?php echo $userName;?>,</p> 
<p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px"> I am  Anoop Rai , Very much happy to send mail using SMTP Script.</p>
</div>
</body>
</html>